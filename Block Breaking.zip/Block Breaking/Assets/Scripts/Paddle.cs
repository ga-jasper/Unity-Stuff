﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Paddle : MonoBehaviour {
    [SerializeField] float ScreenWidthInUnits = 16f;
    [SerializeField] float minx = 1f;
    [SerializeField] float maxx = 16f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        float mousePosInUnits = Input.mousePosition.x / Screen.width * ScreenWidthInUnits;
        Vector2 paddlePosition = new Vector2(mousePosInUnits, transform.position.y);
        paddlePosition.x = Mathf.Clamp(mousePosInUnits, minx, maxx);
        transform.position = paddlePosition;
	}
}
