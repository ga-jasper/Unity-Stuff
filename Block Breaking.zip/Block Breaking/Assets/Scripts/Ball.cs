﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {
    [SerializeField] Paddle paddle1;
    Vector2 paddleToBall;
    bool hasStarted = false;
    [SerializeField] float xpush = 0f;
    [SerializeField] float ypush = 0f;
	// Use this for initialization
	void Start () {
        paddleToBall = transform.position - paddle1.transform.position;
	}

    // Update is called once per frame
    void Update()
    {
        if (hasStarted == false) {
        LockToPaddle();
        LaunchOnClick();
        }
	}

    private void LaunchOnClick()
    {
        if (Input.GetMouseButtonDown(0)){
            hasStarted = true;
            GetComponent<Rigidbody2D>().velocity = new Vector2(xpush, ypush);
        }
    }

    private void LockToPaddle()
    {
        Vector2 paddlePosition = new Vector2(paddle1.transform.position.x, paddle1.transform.position.y);
        transform.position = paddlePosition + paddleToBall;
    }
}
